/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

/**
 *
 * @author root
 */
//@CustomFormAuthenticationMechanismDefinition(
//        loginToContinue = @LoginToContinue(
//                loginPage = "/index.jsp"
//              
//        )
//)
//@DatabaseIdentityStoreDefinition(
//  dataSourceLookup = "jdbc/mysql",
//  callerQuery = "select password from users where username = ?",
//  groupsQuery = "select GROUPNAME from groups where username = ?",
//  hashAlgorithm = Pbkdf2PasswordHash.class,
//  priority=30)

//@OpenIdAuthenticationDefinition(
//        providerURI = "https://accounts.google.com",   
//        responseType = "code",
//        clientId = "727311471023-seq5hcaakcb0fmlhcok5qs1t4313qirq.apps.googleusercontent.com",
//        clientSecret = "mb4o7OgvrpTtGF1ZPZnbAIqk",
//        redirectURI = "https://localhost:8181/RestPublishApp-war/PubRestServlet",
//         scope =  {"email","openid","profile"}
//        
//)
//@Named
//@ApplicationScoped
public class ProjectConfig {
    
}
